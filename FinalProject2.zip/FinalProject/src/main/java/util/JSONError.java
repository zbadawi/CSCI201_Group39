package util;

public class JSONError {
	public String error;
	
	public JSONError(String message) {
		this.error = message;
	}
}
